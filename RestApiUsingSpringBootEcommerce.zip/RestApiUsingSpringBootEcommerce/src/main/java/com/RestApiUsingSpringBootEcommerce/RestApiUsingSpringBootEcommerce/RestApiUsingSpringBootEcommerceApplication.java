package com.RestApiUsingSpringBootEcommerce.RestApiUsingSpringBootEcommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiUsingSpringBootEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiUsingSpringBootEcommerceApplication.class, args);
	}

}
