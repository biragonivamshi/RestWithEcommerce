package com.RestApiUsingSpringBootEcommerce.RestApiUsingSpringBootEcommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiUsingSpringBootEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
